#include <stdio.h>
#include <locale.h>//Este tem a fun��o de nos deixar utilizar s�mbolos gramaticais, como acentos e �, por exemplo.
#include <time.h>
#include <math.h>//Fun��o para a realiza��o de contas matem�ticas.

int main()
{
    setlocale (LC_ALL,"Portuguese");//Est� ligado ao <locale.h>, definindo o idioma .
   //As fun��es a seguir, tem como finalidade mostrar a hora em que o programa esta sendo utilizado.
    struct tm *data_hora_atual;

    time_t segundos;


    time(&segundos);


    data_hora_atual = localtime(&segundos);


    char nome_prop[10][100],casa_apto[10][100],rua[10][100] ,bairro[10][100],cidade[10][100],forma_de_pagamento[10][100];
    int menu, numero[100],contrato_minimo=12;
    int total_locadores = 0,total_locadores_aluguel=0;//Houve a separa��o do total de ambos os clientes.
    float valor_mes[100], valor_a_pagar[100],area_total[100],valort;

    printf("\nHora ........: %d:",data_hora_atual->tm_hour);
    printf("%d:",data_hora_atual->tm_min);
    printf("%d\n",data_hora_atual->tm_sec);

	while(1){//O while aparece para fazer com que ocorra sempre a repeti��o do menu ao final do preenchimento de um cadastro.

		printf("\n\n\t Menu do cadastro\n");
		printf("   [1. Adicionar novo cliente para venda]\n   [2. Adicionar novo cliente para aluguel]\n   [3. Sair do sistema]\n\n\t");

		scanf("%d",&menu);//O menu aparece coo forma de facilitar e deixar mais claro o que esta ocorrendo no programa.

		switch(menu){//Utilizamos o switch para usar como recurso em rela��o � escolha no no menu, pois existem dois modelos de cadastramento distintos no sistema.

   			case 1://Abaixo utimizamos printf, para deixar uma mensagem ou informar como deveria ser preenchido cada linha de resposta, alem dele temos o scanf, que foi utilizado para capturar a resposta do "cliente".
				printf("Digite o nome do proprietario do im�vel: ");
	            scanf(" %[^\n]s",nome_prop[total_locadores]);
	            printf("\n-----------------------------------------------------------------|\n");

	        	printf("Informe se � casa ou apartamento: ");
	            scanf(" %[^\n]s",casa_apto[total_locadores]);
	            printf("\n------------------------------------------------------------------|\n");

	        	printf("Digite o nome da rua: ");
	            scanf(" %[^\n]s",rua[total_locadores]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("Digite o nome do bairro: ");
	            scanf(" %[^\n]s",bairro[total_locadores]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("Digite o nome da cidade: ");
	            scanf(" %[^\n]s",cidade[total_locadores]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("informe a forma de pagamento: ");
	            scanf(" %[^\n]s",forma_de_pagamento[total_locadores]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("Digite n�mero da casa: ");
	            scanf("%d",&numero[total_locadores]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("Informe a �rea total em m�: ");
	            scanf("%f",&area_total[total_locadores]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("o valor a pagar �: ");
	            scanf("%f",&valor_a_pagar[total_locadores]);break;
				total_locadores++;

				printf("o valor a pagar no contrato m�nimo � %f",valor_a_pagar[total_locadores]);
        	case 2:

	        	printf("Digite o nome do proprietario do imovel: ");
	            scanf(" %[^\n]s",nome_prop[total_locadores_aluguel]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("Informe se � casa ou apartamento: ");
	            scanf(" %[^\n]s",casa_apto[total_locadores_aluguel]);
	            printf("\n-------------------------------------------------------------------|\n");

	        	printf("Digite o nome da rua: ");
	            scanf(" %[^\n]s",rua[total_locadores_aluguel]);
	            printf("\n--------------------------------------------------------------------|\n");

	        	printf("Digite o nome do bairro: ");
	            scanf(" %[^\n]s",bairro[total_locadores_aluguel]);
	            printf("\n--------------------------------------------------------------------|\n");

	        	printf("Digite o nome da cidade: ");
	            scanf(" %[^\n]s",cidade[total_locadores_aluguel]);
	            printf("\n--------------------------------------------------------------------|\n");

	        	printf("informe a forma de pagamento: ");
	            scanf(" %[^\n]s",forma_de_pagamento[total_locadores_aluguel]);
	            printf("\n--------------------------------------------------------------------|\n");

	        	printf("Digite n�mero da casa: ");
	            scanf("%d",&numero[total_locadores_aluguel]);
	            printf("\n--------------------------------------------------------------------|\n");

	        	printf("Informe a �rea total em m�: ");
	            scanf("%f",&area_total[total_locadores_aluguel]);
	            printf("\n--------------------------------------------------------------------|\n");

	        	printf("O tempo de contrato minimo � de %d meses",contrato_minimo);

	            printf("\n--------------------------------------------------------------------|\n");

                printf("o valor a pagar por m�s �: ");
	            scanf("%f",&valor_mes[total_locadores_aluguel]);

                                valor_a_pagar[total_locadores_aluguel] = 12*valor_mes[total_locadores_aluguel];
				printf("o valor a pagar no contrato m�nimo � %.2f",valor_a_pagar[total_locadores_aluguel]);
				break;//O break, tem como fun��o finalizar uma irforma��o do case.

                total_locadores_aluguel++;
        	case 3: return 0;
		}}//Como 1 e 2 foram formas de cadastro, o 3 tem como fun��o finalizar o programa.
    return 0;
}
