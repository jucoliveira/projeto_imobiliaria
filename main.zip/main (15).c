#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <math.h>
#define contrato 12

void imobiliaria(void){
printf("Central");
}
void multiplica (float valor_mes, int c, float valor_a_pagar){
valor_a_pagar=valor_mes*c;

}
int main(void)
{
    setlocale (LC_ALL,"Portuguese");

    struct tm *data_hora_atual;

    time_t segundos;

    time(&segundos);

    data_hora_atual = localtime(&segundos);


    FILE *pont_arq_venda;
    FILE *pont_arq_aluguel;
    char nome_prop[10][100],casa_apto[10][100],rua[10][100] ,bairro[10][100],cidade[10][100],forma_de_pagamento[10][100];
    int menu, numero[100];
    int total_locadores = 0,total_locadores_aluguel=0;
    float valor_mes[100], valor_a_pagar[100],area_total[100];
    int c=contrato;

    pont_arq_venda = fopen("arquivos_venda.txt", "a");
    pont_arq_aluguel = fopen("arquivos_aluguel.txt", "a");



    printf("\nHora ........: %d:",data_hora_atual->tm_hour);
    printf("%d:",data_hora_atual->tm_min);
    printf("%d\n",data_hora_atual->tm_sec);

	while(1){
        printf("\n--> Cadastro de Cliente da Imobiliaria ");
        imobiliaria();
		printf("\n\n\t Menu do cadastro\n");
		printf("   [1. Adicionar novo cliente para venda]\n   [2. Adicionar novo cliente para aluguel]\n   [3. Sair do sistema]\n\n\t");

		scanf("%d",&menu);

		switch(menu){

   			case 1:
   			    if(pont_arq_venda==NULL){
        printf("Erro na abertura do arquivo");
        return 1;
    }
    else{
				printf("Digite o nome do proprietario do im�vel: ");
	            scanf(" %[^\n]s",nome_prop[total_locadores]);
	            fprintf(pont_arq_venda,"%s\n",nome_prop[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	        	printf("Informe se � casa ou apartamento: ");
	            scanf(" %[^\n]s",casa_apto[total_locadores]);
	            fprintf(pont_arq_venda,"%s\n",casa_apto[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	        	printf("Digite o nome da rua: ");
	            scanf(" %[^\n]s",rua[total_locadores]);
	            fprintf(pont_arq_venda,"%s\n",rua[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	        	printf("Digite o nome do bairro: ");
	            scanf(" %[^\n]s",bairro[total_locadores]);
	            fprintf(pont_arq_venda,"%s\n",bairro[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	        	printf("Digite n�mero da casa: ");
	            scanf("%d",&numero[total_locadores]);
	            fprintf(pont_arq_venda,"%d\n",numero[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	            printf("Digite o nome da cidade: ");
	            scanf(" %[^\n]s",cidade[total_locadores]);
	            fprintf(pont_arq_venda,"%s\n",cidade[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	        	printf("Informe a �rea total em m�: ");
	            scanf("%f",&area_total[total_locadores]);
	            fprintf(pont_arq_venda,"%.2f\n",area_total[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	            printf("informe a forma de pagamento: ");
	            scanf(" %[^\n]s",forma_de_pagamento[total_locadores]);
	            fprintf(pont_arq_venda,"%s\n",forma_de_pagamento[total_locadores]);
	            printf("\n----------------------------------------------|\n");

	        	printf("o valor a pagar por �: ");
	            scanf("%f",&valor_a_pagar[total_locadores]);
	            fprintf(pont_arq_venda,"%.2f\n\n",valor_a_pagar[total_locadores]);break;
				total_locadores++;

				fclose(pont_arq_venda);}

        	case 2:

        	if( pont_arq_aluguel==NULL){
          printf("Erro na abertura do arquivo");
          return 0;}
          else{

	        	printf("Digite o nome do proprietario do imovel: ");
	            scanf(" %[^\n]s",nome_prop[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%s\n",nome_prop);
	            printf("\n----------------------------------------------|\n");

	        	printf("Informe se � casa ou apartamento: ");
	            scanf(" %[^\n]s",casa_apto[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%s\n",casa_apto);
	            printf("\n----------------------------------------------|\n");

	        	printf("Digite o nome da rua: ");
	            scanf(" %[^\n]s",rua[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%s\n",rua);
	            printf("\n----------------------------------------------|\n");

	        	printf("Digite o nome do bairro: ");
	            scanf(" %[^\n]s",bairro[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%s\n",bairro);
	            printf("\n----------------------------------------------|\n");


	        	printf("Digite n�mero da casa: ");
	            scanf("%d",&numero[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%d\n",numero[total_locadores_aluguel]);
	            printf("\n----------------------------------------------|\n");

	            printf("Digite o nome da cidade: ");
	            scanf(" %[^\n]s",cidade[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%s\n",cidade);
	            printf("\n----------------------------------------------|\n");

	        	printf("Informe a �rea total em m�: ");
	            scanf("%f",&area_total[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%.2f\n",area_total[total_locadores_aluguel]);
	            printf("\n----------------------------------------------|\n");

	            printf("informe a forma de pagamento: ");
	            scanf(" %[^\n]s",forma_de_pagamento[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%s\n",forma_de_pagamento);
	            printf("\n----------------------------------------------|\n");

	        	printf("O tempo de contrato minimo � %d meses",contrato);

	            printf("\n----------------------------------------------|\n");

                printf("o valor a pagar por m�s �: ");
	            scanf("%f",&valor_mes[total_locadores_aluguel]);
	            fprintf(pont_arq_aluguel,"%.2f\n",valor_mes[total_locadores_aluguel]);



                valor_a_pagar[total_locadores_aluguel] = c*valor_mes[total_locadores_aluguel];
				printf("o valor a pagar no contrato m�nimo � %.2f",valor_a_pagar[total_locadores_aluguel]);
				fprintf(pont_arq_aluguel,"%.2f\n\n",valor_a_pagar[total_locadores_aluguel]);
				break;

                total_locadores_aluguel++;
                fclose(pont_arq_aluguel);}
        	case 3: return 0;

		}}
		getch();
    return 0;
}
